
HITGrasp - v2 HITGrasp_v2
==============================

This dataset was exported via roboflow.ai on May 26, 2022 at 1:41 AM GMT

It includes 275 images.
Fruits are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of vertical flip
* Random exposure adjustment of between -4 and +4 percent


