
HITGrasp - v1 HITGrasp_v1
==============================

This dataset was exported via roboflow.ai on May 25, 2022 at 3:13 PM GMT

It includes 182 images.
Fruits are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of vertical flip


